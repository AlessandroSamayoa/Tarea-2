﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea2parte1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 1
            char l1, l2, l3;
            Console.WriteLine("Este es un programa que se colocaran tres letras y las mostrara en orden inverso\n Presione Enter despues de cada letra que escriba");
            Console.WriteLine("Escriba la primera letra: ");
            l1 = char.Parse(Console.ReadLine());
            Console.WriteLine("Escriba la segunda letra: ");
            l2 = char.Parse(Console.ReadLine());
            Console.WriteLine("Escriba la tercera letra: ");
            l3 = char.Parse(Console.ReadLine());
            Console.WriteLine("Las letras son : "+l3+" "+l2+" "+l1);
            Console.WriteLine("Presione cualquier letra para continuar");
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 2
            bool valid = true;
            while (valid){
            Console.WriteLine("Escriba un número de 1 a 9 que mostrara un triángulo con la anchura\nde ese mismo número y formado por el mismo número que escriba");
            Console.WriteLine("Presione Enter despues del número");
           
                int n, lineas, ancho;
                n = int.Parse(Console.ReadLine());
                Console.Clear();
                if (n > 0 && n < 10) n = n * 1; else { n = n * 0; Console.WriteLine("Solo puede escoger un número dentro de 1 a 9");
                    } 
                for (lineas = 1; lineas <= n; lineas++)
                {
                    for (ancho = 0; ancho <= n - lineas; ancho++)
                    { Console.Write(n); }
                    Console.WriteLine("\n");
                }
                bool valid2 = true;
                while (valid2)
                {
                Console.WriteLine("Desea repetir programa o continuar\n1.Repetir\n2.continuar");
                int continuar = int.Parse(Console.ReadLine());
                Console.Clear();
                                   
                    switch (continuar)
                    {
                        case 1:
                            Console.Clear();
                            valid = true;
                            valid2 = false;
                            break;
                        case 2:
                            valid = false;
                            valid2 = false; 
                            break;
                        default:
                            Console.WriteLine("Selección invalida");
                            valid2 = true;
                            break;
                    }
                }
            }

            //Ejercicio 3
            //La contraseña es "billy" y la clave es "1234"//
            int i = 1;
            bool repeat = true;
            while (repeat)
            {
                Console.WriteLine("Por favor escriba su usuario y su contraseña");
                Console.WriteLine("Usuario: ");
                string usuario = Console.ReadLine();
                Console.WriteLine("Contraseña: ");
                string contraseña = Console.ReadLine();
                Console.WriteLine("Escriba su usuario y contraseña");
                Console.Clear();
                if (usuario == "billy" && contraseña == "1234")
                {
                    Console.WriteLine("Bienvenido a su cuenta Mr. " + usuario); Console.ReadKey(); repeat = false;
                }
                else
                {
                    while (i <= 3)
                    {
                        i = i + 1;
                        Console.WriteLine("Escriba bien su Usuario o Contraseña");
                        repeat = true;
                        break;
                    }
                }
                if (i == 4)
                {
                    Console.Clear();
                    Console.WriteLine("Intento más de tres veces, sesión finalizada\nCualquier tecla para continuar");
                    Console.ReadKey();
                    repeat = false;
                }
            }
           

            }
        }
}
