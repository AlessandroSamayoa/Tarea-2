﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea2parte2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 4//
            bool operar = true;
            while (operar) {
                Console.WriteLine("Ejercicio 4\nTomar dos números de entrada y llevar a cabo una operación (+, -, *, x, /)\nen ellos y muestra el resultado de esa operación.");
                float n1, n2;
                float n4;
                Console.WriteLine("Escriba el primer número: ");
                n1 = float.Parse(Console.ReadLine());
                Console.WriteLine("Escriba la operacion que desea efectuar (+, -, *, /): ");
                string n3 = Console.ReadLine();
                Console.WriteLine("Escriba el segundo número: ");
                n2 = float.Parse(Console.ReadLine());
                n4 = 1;

                if (n3 == "+") n4 = n1 + n2;
                else { if (n3 == "-") n4 = n1 - n2;
                    else { if (n3 == "*") n4 = n1 * n2;
                        else { if (n3 == "/") n4 = n1 / n2;
                            else { Console.Clear(); Console.WriteLine("Profavor escriba uno de estos caracteres +, -, *, /"); n4 = n4 * 0;
                            } } } }
                Console.WriteLine("\nEl resultado es: " + n4);
                Console.WriteLine("\n¿Qué desea hacer\n1.Regresar al principio\n2.Continuar al siguiente programa");
                Console.WriteLine("Presione Enter después de la opción que coloque");
                int salir = int.Parse(Console.ReadLine());
                switch (salir) {
                    case 1:
                        operar = true;
                        Console.Clear();
                        break;
                    case 2:
                        operar = false;
                        Console.Clear();
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Parametro Invalido, presione cualquier tecla para regresar al principio");
                        Console.ReadKey();
                        operar = true;
                        Console.Clear();
                        break;
                }
            }
            //Ejercicio 5//
            Console.WriteLine("Ejercicio 5\nEscriba el radio del circulo y obtendra el perímetro y área del círculo");
            double rad, peri, area;
            Console.WriteLine("Radio: ");
            rad = double.Parse(Console.ReadLine());
            peri = Math.PI * 2 * rad;
            area = Math.PI * Math.Pow(rad, 2);
            Console.WriteLine("\nEl perímetro del círculo de radio " + rad + " es " + peri);
            Console.WriteLine("El área del círculo de radio " + rad + " es " + area);
            Console.WriteLine("\nPresione cualquier letra para continuar");
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 6//
            Console.WriteLine("Ejercicio 6\nVisualizar ciertos valores de la función x = y^2 + 2y + 1 (usando números enteros para y, que van de -5 a +5)");
            Console.WriteLine("Presione Enter para observar el resultado\n");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
            double x, z;

            for (z = -5; z <= 5; z++)
            {
                x = Math.Pow(z, 2) + 2 * z + 1;
                Console.WriteLine("Cuando 'y' vale " + z + " en la función x = (" + z + "^2) + 2(" + z + ") + 1, entonces 'x' vale: " + x);
            }
            Console.WriteLine("\nFin del programa 2 de la tarea 2");
            Console.WriteLine("Presione Esc para salir");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }

        }
    }
}
