﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea2parte3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 7//
            Console.WriteLine("Ejercicio 7");
            double dist, hora, min, seg, mxs, kmxh, mixh, htotal, distkm;
            Console.WriteLine("Escriba la distancia en metros: ");
            dist = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba las hora: ");
            hora = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba los minutos: ");
            min = double.Parse(Console.ReadLine());
            Console.WriteLine("Escriba los segundos: ");
            seg = double.Parse(Console.ReadLine());
            htotal = hora + min / 60 + seg / 3600;
            distkm = dist / 1000;
            kmxh = distkm / htotal;
            mxs = kmxh * 1000 / 3600;
            mixh = kmxh / 1.60934;
            Console.WriteLine("\nSu velocidad en m/s es " + mxs);
            Console.WriteLine("Su velocidad en km/h es " + kmxh);
            Console.WriteLine("Su velocidad en millas/h es " + mixh);
            Console.WriteLine("\nPresione cualquier letra para continuar");
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 8//
            Console.WriteLine("Ejercicio 8");
            double radio, superficie, volumen;
            Console.WriteLine("Escriba el radio de la esfera, calculara el volumen de la esfera y la superficie");
            Console.WriteLine("Escriba el radio: ");
            radio = double.Parse(Console.ReadLine());
            volumen = (4 / 3) * Math.PI * Math.Pow(radio, 3);
            superficie = 4 * Math.PI * Math.Pow(radio, 2);
            Console.WriteLine("\nEl volumen de la esfera es: " + volumen);
            Console.WriteLine("La superficie de la esfera es: " + superficie);
            Console.WriteLine("\nPresione cualquier tecla para continuar");
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 9//
            string l;
            Console.WriteLine("Ejercicio 9\nTomar un caracter y comprobar si es vocal, un dígito, o cualquier otro símbolo.");
            Console.WriteLine("Escriba la letra y luego presione Enter");
            l = Console.ReadLine();
            Console.WriteLine();
            if (l == "a" || l == "e" || l == "i" || l == "o" || l == "u") Console.WriteLine(l + " es una vocal mínuscula");
            else if (l == "b" || l == "c" || l == "d" || l == "f" || l == "g" ||
                l == "h" || l == "j" || l == "k" || l == "l" || l == "m" ||
                l == "n" || l == "ñ" || l == "p" || l == "q" || l == "r" ||
                l == "s" || l == "t" || l == "v" || l == "w" || l == "x" ||
                l == "y" || l == "z")
                Console.WriteLine(l + " es una letra mínuscula");
            else if (l == "1" || l == "2" || l == "3" || l == "4" || l == "5" || l == "6" || l == "7" || l == "8" || l == "9")
                Console.WriteLine(l + " es un digito");
            else Console.WriteLine(l + " es un simbolo");
            Console.WriteLine("Presione Esc para salir");
            while (Console.ReadKey().Key != ConsoleKey.Escape) { }
            Console.Clear();
        }
    }
}
