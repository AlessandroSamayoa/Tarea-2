﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea2parte4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejercicio 10//
            Console.WriteLine("Ejercicio 10\nTomar dos números y que devuelvan verdadero cuando ambos números son pares");
            int nu1, nu2;
            Console.WriteLine("Escriba el primero número: ");
            nu1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Escriba el segundo número ");
            nu2 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            if (nu1 % 2 == 0 && nu2 % 2 == 0 )  Console.WriteLine("Ambos números son par, es verdadero");
            else Console.WriteLine("Es falso");

            Console.WriteLine("Presione cualquier tecla para continuar");
            Console.ReadKey();
            Console.Clear();

            //Ejercicio 11//
            /*Escribir un programa en C# que toma un número decimal como entrada y muestra su equivalente en forma binaria.
            Datos de prueba:
            Número para convertir ? 25
            Resultado esperado:
            Binario:11001*/
            Console.WriteLine("Ingrese un numero entero ");
            int Num = Convert.ToInt32(Console.ReadLine());
            if (Num > 0)
            {
                String cad = "";
                while (Num > 0)
                {
                    if (Num % 2 == 0)
                    {
                        cad = "0" + cad;
                    }
                    else
                    {
                        cad = "1" + cad;
                    }
                    Num = (int)(Num / 2);
                }
                Console.WriteLine("En numeros binarios es: "+cad);
            }
            else
            {
                if (Num == 0)
                {
                    Console.WriteLine("0");
                }
                else
                {
                    Console.WriteLine("Solo numeros positivos");
                }
            }
            Console.WriteLine("Presione cualquier tecla para salir");
            Console.ReadLine();










        }
    }
}
